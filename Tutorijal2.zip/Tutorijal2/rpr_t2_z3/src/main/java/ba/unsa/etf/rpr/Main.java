package ba.unsa.etf.rpr;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static java.lang.Math.pow;
import static java.lang.Math.sqrt;
public class Main {

    public static void main(String[] args) {

        int broj;
        int maximum = 0, minumum = 0, suma = 0;
        double mean = 0;
        double sd = 0.0;
        double rez = 0;
        List<Integer> brojevi = new ArrayList<Integer>();

        Scanner in = new Scanner(System.in);
        do {
            System.out.println("Unesi brojeve: ");
            broj = in.nextInt();
           brojevi.add(broj);
        }while(broj != Integer.parseInt("stop"));

           for (int i = 0; i < brojevi.size(); i++) {
                if (brojevi.get(i) > maximum) maximum = brojevi.get(i);
                if (brojevi.get(i) < minumum) minumum = brojevi.get(i);

                suma += brojevi.get(i);
                mean = (double) suma / brojevi.size();
                sd += pow(brojevi.get(i) - mean, 2);
                rez = sqrt(sd / brojevi.size());
            }

        System.out.println("Maximum je: "+maximum+" Minimum je: "+minumum+" Mean je: "+mean+" " +
                " Standardna devijacija je: "+rez);
    }
}