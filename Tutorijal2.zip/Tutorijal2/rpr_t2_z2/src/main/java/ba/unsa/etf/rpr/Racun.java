package ba.unsa.etf.rpr;

public class Racun {
  private final Long brojRacuna;
  private final Osoba korisnikRacuna;
  private boolean odobrenjePrekoracenja;
  private Double stanjeRacuna;

   public Racun(long brojRacuna,Osoba korisnikRacuna){

    this.brojRacuna = brojRacuna;
    this.korisnikRacuna = korisnikRacuna;
    this.stanjeRacuna = 0d;
    this.odobrenjePrekoracenja = false;
    }
    public boolean provjeriOdobrenjePrekoracenje(double r)
    {

    }

    public boolean izvrsiUplstu(double r)
    {

    }

    public boolean izvrsiIsplatu(double r)
    {

    }

    public void odobriPrekoracenje(double r)
    {

    }
*/

}
