package ba.unsa.etf.rpr;

public class Main {
    public static void main(String[] args) {
        Banka banka = new Banka();
        Korisnik k1 = banka.kreirajNovogKorisnika("Maja", "Majić");
        banka.kreirajRacunZaKorisnika(k1);
        k1.dodajRacun().izvrsiUplatu(2345.45d);
        banka.kreirajNovogUposlenika()("Marko", "Marić");
      //  KreditnaSposobnost funkcija = (Racun racun) -> {
        //    double stanje = racun.getStanjeRacuna().doubleValue();
          //  if (stanje > 1000) {
            //    return stanje / 2;
            //} else {
              //  return 0d;
           // }
        };


    }
}