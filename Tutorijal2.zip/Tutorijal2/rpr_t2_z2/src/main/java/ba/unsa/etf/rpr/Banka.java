package ba.unsa.etf.rpr;

import java.util.List;

import java.util.ArrayList;

public class Banka {
    private static long brojRacuna = 100000000000000000L;
    private List<Korisnik> korisnici;
    private List<Uposlenik>uposlenici;
    public Banka(){
        uposlenici = new ArrayList<>();
        korisnici = new ArrayList<>();
    }
    public Banka(long brojRacuna) {
        this.brojRacuna = brojRacuna;
    }
   public Korisnik kreirajNovogKorisnika(String n,String sn)

    {
       Korisnik kn = new Korisnik(String n,String sn);
        return kn;
    }
    public Uposlenik kreirajNovogUposlenika(String n, String sn)
    {
        Uposlenik u = new Uposlenik(n,sn);
        return u;
    }
    public Racun kreirajRacunZaKorisnika(Korisnik k)
    {
    }*/


}
