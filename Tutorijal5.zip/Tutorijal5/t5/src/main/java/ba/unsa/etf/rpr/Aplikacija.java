package ba.unsa.etf.rpr;

import ba.unsa.etf.rpr.BuilderPattern.BuilderMobilePhone;
import ba.unsa.etf.rpr.BuilderPattern.MobilePhone;
import ba.unsa.etf.rpr.FactoryPattern.OperativniSistem;
import ba.unsa.etf.rpr.FactoryPattern.OperativniSistemFactory;

public class Aplikacija {

    public static void main(String[] args)
    {

         /* Test Builder patterna, otkomentarisati za rad */
                          MobilePhone mobitel = (new BuilderMobilePhone("Android")).
                          setBaterija(5000).setMegapixeli(48).setProcesor("Snapdragon 865 5nm").build();
                         System.out.println(mobitel);




        /* Test Factory patterna, otkomentarisati za rad*/
                  OperativniSistemFactory operativniSistemFactory = new OperativniSistemFactory();
                  OperativniSistem os = operativniSistemFactory.getInstance("Closed source");
                  os.specifikacije();
    }
}
