package ba.unsa.etf.rpr;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class LaptopDaoXMLFile implements LaptopDao {

    File file;
    ArrayList<Laptop> laptopi;


    public LaptopDaoXMLFile() {
        file = new File("laptopi.xml");
        laptopi = new ArrayList<Laptop>();
    }

    public void dodajLaptopUListu(Laptop laptop) {

    }

    public void dodajLaptopUFile(Laptop laptop) throws IOException {
        laptopi.add(laptop);
        ObjectMapper xml = new XmlMapper();
        FileOutputStream fos = new FileOutputStream(file);
        String s = xml.writeValueAsString(laptopi);
        fos.write(s.getBytes());
        fos.close();
    }

    public Laptop getLaptop(String procesor) {
        return null;
    }

    public void napuniListu(ArrayList<Laptop> laptopi) {

    }

    public String vratiPodatkeIzDatoteke() {
        return null;
    }

}
