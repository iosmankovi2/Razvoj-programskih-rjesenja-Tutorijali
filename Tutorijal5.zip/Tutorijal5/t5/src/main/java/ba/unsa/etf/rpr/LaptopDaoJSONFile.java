package ba.unsa.etf.rpr;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class LaptopDaoJSONFile implements LaptopDao {

    File file;
    ArrayList<Laptop> laptopi;


    public LaptopDaoJSONFile() {
        file = new File("laptopi.json");
        laptopi = new ArrayList<Laptop>();
    }

    public void dodajLaptopUListu(Laptop laptop) {
        laptopi.add(laptop);
    }

    public void dodajLaptopUFile(Laptop laptop) throws IOException {
        laptopi.add(laptop);
        ObjectMapper om = new JsonMapper();
        FileOutputStream fos = new FileOutputStream(file);
        String s = om.writeValueAsString(laptopi);
        fos.write(s.getBytes());
        fos.close();
    }

    public Laptop getLaptop(String procesor) {
        return null;
    }

    public void napuniListu(ArrayList<Laptop> laptopi) {

    }

    public String vratiPodatkeIzDatoteke() {
        return null;
    }
}
