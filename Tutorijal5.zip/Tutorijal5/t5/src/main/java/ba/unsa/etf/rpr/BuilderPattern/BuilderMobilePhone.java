package ba.unsa.etf.rpr.BuilderPattern;

public class BuilderMobilePhone {

    private final String operativniSistem;
    private String procesor;
    private Double displayVelicina;
    private Integer baterija;
    private Integer megapixeli;

    public BuilderMobilePhone(String operativniSistem)
    {
        this.operativniSistem = operativniSistem;
    }

    public MobilePhone build()
    {
        return new MobilePhone(operativniSistem,procesor,displayVelicina,baterija,megapixeli);
    }

    public BuilderMobilePhone setProcesor(String procesor) {
        this.procesor = procesor;
        return this;
    }

    public BuilderMobilePhone setDisplayVelicina(Double displayVelicina) {
        this.displayVelicina = displayVelicina;
        return this;
    }

    public BuilderMobilePhone setBaterija(Integer baterija) {
        this.baterija = baterija;
        return this;
    }

    public BuilderMobilePhone setMegapixeli(Integer megapixeli) {
        this.megapixeli = megapixeli;
        return this;
    }
}
