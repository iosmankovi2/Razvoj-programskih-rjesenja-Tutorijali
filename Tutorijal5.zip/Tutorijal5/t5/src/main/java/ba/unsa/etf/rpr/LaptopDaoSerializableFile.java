package ba.unsa.etf.rpr;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import java.io.*;
import java.util.ArrayList;


public class LaptopDaoSerializableFile implements LaptopDao {

    File file;
    ArrayList<Laptop> laptopi;

    public LaptopDaoSerializableFile()
    {
        file = new File("laptopi.txt");
        laptopi = new ArrayList<Laptop>();
    }

    public void dodajLaptopUListu(Laptop laptop) {
        laptopi.add(laptop);
    }

    public void dodajLaptopUFile(Laptop laptop) throws IOException {
        laptopi.add(laptop);
        ObjectMapper om = new ObjectMapper();
        FileOutputStream fos = new FileOutputStream(file);
        String s = om.writeValueAsString(laptopi);
        fos.write(s.getBytes());
        fos.close();
    }

    public Laptop getLaptop(String procesor) {
        return null;
    }

    public void napuniListu(ArrayList<Laptop> laptopi) {

    }

    public String vratiPodatkeIzDatoteke() {
        return null;
    }
}