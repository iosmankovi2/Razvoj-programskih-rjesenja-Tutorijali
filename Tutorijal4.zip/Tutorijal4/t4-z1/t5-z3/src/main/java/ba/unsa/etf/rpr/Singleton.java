package ba.unsa.etf.rpr;

public class Singleton {

}
