import ba.unsa.etf.rpr.FiksniBroj;
import ba.unsa.etf.rpr.MedunarodniBroj;
import org.testng.annotations.Test;

import static ba.unsa.etf.rpr.Grad.SARAJEVO;

public @interface Imenik {

    @Test
                void dodaj() {
                Imenik imenik = new Imenik();
                imenik.dodaj("Lana Lanić", new MedunarodniBroj("+1", "23 45-67-89"));
                imenik.dodaj("Sara Saric", new FiksniBroj(SARAJEVO, "123-156"));
                imenik.dodaj("Meho Mehic", new FiksniBroj(SARAJEVO, "123-456"));

            }

            }
}
