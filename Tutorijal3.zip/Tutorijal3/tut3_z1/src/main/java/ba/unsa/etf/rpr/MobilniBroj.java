package ba.unsa.etf.rpr;

public class MobilniBroj extends TelefonskiBroj {

    private int mobilnaMreza;
    private String broj;


    public MobilniBroj(int mobilnaMreza, String broj) throws  IllegalArgumentException {

        if(mobilnaMreza < 60 || mobilnaMreza > 67) throw  new  IllegalArgumentException("Mreža nije ispravna!");
        this.mobilnaMreza = mobilnaMreza;
        this.broj = broj;
    }

        @Override

        public int hashCode() {
        return  0;
    }

        @Override

        public String ispisi() {

        return "0"+mobilnaMreza+"/"+broj;
    }
}

