package ba.unsa.etf.rpr;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Imenik {

    /*pretraživanje brojeva koristeći HashMap-u*/
    private HashMap<String, TelefonskiBroj> brojKorisnika = new HashMap<>();

    public void dodaj(String ime, TelefonskiBroj broj) {
    }

    public String dajBroj(String ime) {
        return brojKorisnika.get(ime).ispisi();
    }

    public String dajIme(TelefonskiBroj broj) {
        for (Map.Entry<String, TelefonskiBroj> elementi : brojKorisnika.entrySet()) {
            if (elementi.getValue().compareTo(broj) == 0) return elementi.getKey();
        }
        return "";
    }

    public String naSlovo(char s) {
        int br = 1;
        StringBuilder ljudi = new StringBuilder();
        for (Map.Entry<String, TelefonskiBroj> elementi : brojKorisnika.entrySet()) {
            if (elementi.getKey().charAt(0) == s) {
                ljudi.append(String.format("%d. %s - %s\n", br, elementi.getKey(), elementi.getValue().ispisi()));
                br++;
            }
        }
        return ljudi.toString();
    }

    public Set<TelefonskiBroj> izGrada(Grad g) {
        Set<TelefonskiBroj> gradskiBrojevi = new TreeSet<>();
        for (Map.Entry<String, TelefonskiBroj> elementi : brojKorisnika.entrySet()) {
            TelefonskiBroj broj = elementi.getValue();
            if (broj instanceof FiksniBroj) {
                if (((FiksniBroj) broj).getGrad().equals(g)) gradskiBrojevi.add(elementi.getValue());
            }
        }
        return gradskiBrojevi;
    }

    public Set<TelefonskiBroj> izGradaBrojevi(Grad g) {
        Set<TelefonskiBroj> gradskiBrojevi = new TreeSet<>();
        for (Map.Entry<String, TelefonskiBroj> elementi : brojKorisnika.entrySet()) {
            TelefonskiBroj broj = elementi.getValue();
            if (broj instanceof FiksniBroj) {
                if (((FiksniBroj) broj).getGrad().equals(g)) gradskiBrojevi.add(elementi.getValue());
            }
        }
        return gradskiBrojevi;
    }
}